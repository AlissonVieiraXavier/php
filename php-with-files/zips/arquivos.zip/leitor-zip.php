<?php

echo file_get_contents(filename:'zip://zips.zip#t.txt');